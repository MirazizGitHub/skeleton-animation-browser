/* =============================================
   SkelED Runtime v3.1  —  skel-runtime.js
   =============================================
   SkelActor (oson sintaksis — Spine kabi):
     const hero = new SkelActor('hero/skeleton.json');
     hero.setOffset(400, 300);
     hero.setZIndex(1);
     hero.play('idle');
     hero.on('hit', () => dealDamage());

   SkelRuntime (to'liq nazorat):
     const sk = await SkelRuntime.load('hero/skeleton.json');
   ============================================= */

class SkelRuntime {

  static load(jsonPath, opts={}) {
    return fetch(jsonPath)
      .then(r=>{ if(!r.ok) throw new Error('[SkelED] Cannot load: '+jsonPath); return r.json(); })
      .then(data=>{
        const base=jsonPath.substring(0,jsonPath.lastIndexOf('/')+1);
        const atlasPath=data.atlas?base+data.atlas:null;
        return new SkelRuntime(data,{...opts,atlasPath});
      });
  }

  constructor(data,opts={}) {
    this.bones      = data.bones.map(b=>({...b}));
    this.anims      = data.animations;
    this.blendDur   = data.blendDuration??0.3;
    this.offsetX    = 0;
    this.offsetY    = 0;
    this.scaleX     = 1;
    this.scaleY     = 1;
    this.zIndex     = data.zIndex ?? 0;  // ← JSON dan o'qiladi
    this.paused     = false;   // ← pause/resume
    this.curAnim    = null;
    this.playTime   = 0;
    this.blending   = false;
    this.blendFrom  = null;
    this.blendTo    = null;
    this.blendT     = 0;
    this.onDrawBone = opts.onDrawBone||null;
    this._atlas     = null;
    this._atlasReady= false;
    this._listeners = {};      // ← event listeners
    this._evFired   = new Set();
    if(opts.atlasPath){
      const img=new Image();
      img.onload=()=>{this._atlas=img;this._atlasReady=true;};
      img.onerror=()=>console.warn('[SkelED] atlas yuklanmadi:',opts.atlasPath);
      img.src=opts.atlasPath;
    }
  }

  // ── Pozitsiya ──────────────────────────────────
  setOffset(x,y)  { this.offsetX=x; this.offsetY=y; return this; }
  setScale(sx,sy) { this.scaleX=sx; this.scaleY=sy??sx; return this; }
  flipX()         { this.scaleX*=-1; return this; }
  setZIndex(z)    { this.zIndex=z; return this; }

  // ── Pause / Resume ─────────────────────────────
  pause()  { this.paused=true;  return this; }
  resume() { this.paused=false; return this; }

  // ── Animatsiya ─────────────────────────────────
  play(nameOrId) {
    const anim=this.anims.find(a=>a.name===nameOrId||a.id===nameOrId);
    if(!anim){console.warn('[SkelED] anim topilmadi:',nameOrId);return this;}
    if(this.curAnim?.id===anim.id)return this;
    if(this.curAnim&&this.blendDur>0){
      this.blendFrom=this.bones.map(b=>({...b}));
      this.blendTo=anim; this.blendT=0; this.blending=true;
    }
    this.curAnim=anim; this.playTime=0;
    this._evFired.clear();
    return this;
  }

  // ── Event listener ─────────────────────────────
  // hero.on('hit', (ev) => { ... })
  on(eventName, callback) {
    if(!this._listeners[eventName]) this._listeners[eventName]=[];
    this._listeners[eventName].push(callback);
    return this;
  }
  off(eventName, callback) {
    if(!callback) { delete this._listeners[eventName]; return this; }
    this._listeners[eventName]=(this._listeners[eventName]||[]).filter(cb=>cb!==callback);
    return this;
  }
  _fire(eventName, data) {
    (this._listeners[eventName]||[]).forEach(cb=>cb(data));
    (this._listeners['*']||[]).forEach(cb=>cb({name:eventName,...data}));
  }

  // ── update(dt) ────────────────────────────────
  update(dt) {
    if(this.paused) return;  // ← paused bo'lsa hech narsa qilma
    if(this.blending){
      this.blendT+=dt;
      const al=Math.min(1,this.blendT/this.blendDur),sm=al*al*(3-2*al);
      this.bones.forEach(bone=>{
        const f=this.blendFrom.find(b=>b.id===bone.id);
        const tk=this.blendTo.keyframes.filter(k=>k.boneId===bone.id);
        if(!f)return;
        const to=tk.length?tk[0]:f;
        bone.x=f.x+(to.x-f.x)*sm; bone.y=f.y+(to.y-f.y)*sm; bone.angle=f.angle+(to.angle-f.angle)*sm;
      });
      if(al>=1){this.blending=false;this.blendFrom=null;this.playTime=0;this._evFired.clear();}
      return;
    }
    if(!this.curAnim) return;
    const prevTime=this.playTime;
    this.playTime=(this.playTime+dt)%this.curAnim.duration;
    // Loop restart
    if(this.playTime<prevTime) this._evFired.clear();
    // Events fire
    const evs=this.curAnim.events||[];
    evs.forEach(ev=>{
      if(ev.time>prevTime&&ev.time<=this.playTime&&!this._evFired.has(ev.id)){
        this._evFired.add(ev.id);
        this._fire(ev.name,{time:ev.time,anim:this.curAnim.name});
      }
    });
    this._interp(this.playTime);
  }

  // ── draw(ctx) ─────────────────────────────────
  // clearRect ni SIZ boshqarasiz.
  // zIndex uchun massivda saqlang va sort qilib chizing.
  draw(ctx) {
    ctx.save();
    ctx.scale(this.scaleX,this.scaleY);
    // zIndex bo'yicha sort: kichik = orqada, katta = oldida
    const sorted=[...this.bones].sort((a,b)=>(a.zIndex||0)-(b.zIndex||0));
    sorted.forEach(bone=>{
      const{wx,wy,wA}=this._worldOf(bone),r=wA*Math.PI/180;
      const ox=(bone.pivotX-.5)*bone.w,oy=(bone.pivotY-.5)*bone.h;
      const cx=(wx/this.scaleX)-(ox*Math.cos(r)-oy*Math.sin(r));
      const cy=(wy/this.scaleY)-(ox*Math.sin(r)+oy*Math.cos(r));
      if(this.onDrawBone){this.onDrawBone(ctx,bone,cx,cy,r,this._atlas);return;}
      ctx.save();ctx.translate(cx,cy);ctx.rotate(r);
      if(this._atlasReady&&bone.uv){
        ctx.drawImage(this._atlas,bone.uv.x,bone.uv.y,bone.uv.w,bone.uv.h,-bone.w/2,-bone.h/2,bone.w,bone.h);
      } else {
        ctx.strokeStyle='rgba(255,255,255,0.6)';ctx.lineWidth=1.5;
        if(bone.type==='circle'){ctx.beginPath();ctx.arc(0,0,bone.w/2,0,Math.PI*2);ctx.stroke();}
        else{ctx.beginPath();ctx.roundRect(-bone.w/2,-bone.h/2,bone.w,bone.h,4);ctx.stroke();}
      }
      ctx.restore();
    });
    ctx.restore();
  }

  getBoneTransform(nameOrId){
    const bone=this.bones.find(b=>b.name===nameOrId||b.id===nameOrId);
    return bone?this._worldOf(bone):null;
  }

  _interp(t){
    this.bones.forEach(bone=>{
      const kfs=this.curAnim.keyframes.filter(k=>k.boneId===bone.id);
      if(!kfs.length)return;
      let a=kfs[0],b=kfs[kfs.length-1];
      for(let i=0;i<kfs.length-1;i++)if(kfs[i].time<=t&&kfs[i+1].time>=t){a=kfs[i];b=kfs[i+1];break;}
      const span=b.time-a.time,al=span?_sk_sm((t-a.time)/span):0;
      bone.x=_sk_lerp(a.x,b.x,al);bone.y=_sk_lerp(a.y,b.y,al);bone.angle=_sk_lerp(a.angle,b.angle,al);
      bone.pivotX=_sk_lerp(a.pivotX??bone.pivotX,b.pivotX??bone.pivotX,al);
      bone.pivotY=_sk_lerp(a.pivotY??bone.pivotY,b.pivotY??bone.pivotY,al);
    });
  }

  _worldOf(bone,visited=new Set()){
    const ox=this.offsetX,oy=this.offsetY;
    if(!bone.parentId)       return{wx:bone.x+ox,wy:bone.y+oy,wA:bone.angle};
    if(visited.has(bone.id)) return{wx:bone.x+ox,wy:bone.y+oy,wA:bone.angle};
    visited.add(bone.id);
    const p=this.bones.find(b=>b.id===bone.parentId);
    if(!p) return{wx:bone.x+ox,wy:bone.y+oy,wA:bone.angle};
    const{wx:px,wy:py,wA:pa}=this._worldOf(p,visited),r=pa*Math.PI/180;
    return{wx:px+bone.x*Math.cos(r)-bone.y*Math.sin(r),wy:py+bone.x*Math.sin(r)+bone.y*Math.cos(r),wA:pa+bone.angle};
  }
}

function _sk_lerp(a,b,t){return a+(b-a)*t;}
function _sk_sm(t){return t*t*(3-2*t);}

/* =============================================
   SkelActor — oson wrapper (Spine uslubi)
   ============================================= */
class SkelActor {
  constructor(jsonPath,opts={}){
    this._ready=false; this._runtime=null; this._queue=[];
    SkelRuntime.load(jsonPath,opts).then(sk=>{
      this._runtime=sk; this._ready=true;
      this._queue.forEach(fn=>fn(sk)); this._queue=[];
    }).catch(err=>console.error('[SkelActor]',err));
  }

  setOffset(x,y)   { return this._do(sk=>sk.setOffset(x,y)); }
  setScale(sx,sy)  { return this._do(sk=>sk.setScale(sx,sy)); }
  flipX()          { return this._do(sk=>sk.flipX()); }
  setZIndex(z)     { return this._do(sk=>sk.setZIndex(z)); }
  pause()          { return this._do(sk=>sk.pause()); }
  resume()         { return this._do(sk=>sk.resume()); }
  play(n)          { return this._do(sk=>sk.play(n)); }
  on(ev,cb)        { return this._do(sk=>sk.on(ev,cb)); }
  off(ev,cb)       { return this._do(sk=>sk.off(ev,cb)); }
  update(dt)       { if(this._ready) this._runtime.update(dt); }
  draw(ctx)        { if(this._ready) this._runtime.draw(ctx); }
  getBoneTransform(n){ return this._ready?this._runtime.getBoneTransform(n):null; }
  get isReady()    { return this._ready; }
  get zIndex()     { return this._ready?this._runtime.zIndex:0; }

  _do(fn){ if(this._ready)fn(this._runtime); else this._queue.push(fn); return this; }
}

/* ── zIndex yordamchi: massivni sort qilib chizish ─
   const actors = [hero, enemy, boss];

   function loop(ts) {
     ctx.clearRect(0,0,W,H);
     actors.sort((a,b)=>a.zIndex-b.zIndex)
           .forEach(a=>{ a.update(dt); a.draw(ctx); });
     requestAnimationFrame(loop);
   }
   ─────────────────────────────────────────────── */
